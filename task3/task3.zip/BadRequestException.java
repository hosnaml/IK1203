public class BadRequestException extends Exception {
    
}
