public class IncorrectRequestMethod extends Exception{
    
}
